# Paradosxia Cars を公開する手順（Vercel）

パソコンでNext.jsを動かせなくても大丈夫です。**Vercelがクラウドでビルド**します。
ターミナル（黒い画面）は一切使いません。すべてブラウザの操作だけで完了します。

公開すると、**Splineの3DもTikTok埋め込みも初めて正しく表示されます**。
（これらは「本物のWebサイト」上でしか動かないため、今まで白く見えていました）

---

## 用意するもの（どちらも無料）

1. **GitHub** アカウント … コードの置き場所
2. **Vercel** アカウント … 公開・ビルドする場所（GitHubでログインできます）

---

## STEP 1. zipを解凍する

- `paradosxia-cars.zip` を解凍します。
- 中に `paradosxia` というフォルダができます。
- その中に `package.json` `src` `README.md` などが入っていることを確認します。

---

## STEP 2. GitHubでリポジトリ（置き場所）を作る

1. https://github.com/new を開く（未ログインなら先に無料登録）
2. **Repository name** に `paradosxia-cars` と入力
3. 公開設定は **Public** のままでOK
4. 下の「Add a README」などのチェックは**入れない**
5. **Create repository**（緑のボタン）を押す

---

## STEP 3. ファイルをWebからアップロード（ターミナル不要）

1. 作成直後のリポジトリ画面で **「uploading an existing file」** のリンクを押す
   （または `Add file` → `Upload files`）
2. STEP1で解凍した **`paradosxia` フォルダの「中身」** をすべて選んで、
   アップロード欄にドラッグ＆ドロップする
   - ⚠️ `paradosxia` フォルダ自体ではなく、**中身**（`package.json` や `src` フォルダなど）を入れます
   - `src` フォルダはそのままドラッグすれば中の階層も保持されます
3. アップロードできたら、画面下の **Commit changes**（緑のボタン）を押す
4. リポジトリのトップに `package.json` `src` `README.md` が**直接**並んでいればOK

> もし `paradosxia` フォルダごと上げてしまっても大丈夫です。
> その場合はSTEP4で **Root Directory** に `paradosxia` を指定すれば動きます（後述）。

---

## STEP 4. Vercelでインポートして公開する

1. https://vercel.com を開く
2. **Continue with GitHub** を選んでサインアップ／ログイン
3. （初回のみ）**Install Vercel for GitHub** を求められたら許可する
   - アクセス範囲は **All repositories** でOK
4. ダッシュボードで **Add New…** → **Project** を押す
5. 一覧から `paradosxia-cars` を見つけて **Import** を押す
6. 設定画面が出ます。**何も変更しなくてOK**です
   - Framework Preset が **Next.js** に自動でなっていることだけ確認
   - （STEP3でフォルダごと上げた人だけ）**Root Directory** の `Edit` を押して `paradosxia` を選ぶ
   - 環境変数（Environment Variables）は**不要**です
7. **Deploy** を押す
8. 1分ほどでビルドが完了し、**お祝い画面**と公開URL（例 `paradosxia-cars.vercel.app`）が出ます

---

## STEP 5. 公開URLで確認する

- 発行された `〇〇.vercel.app` を、**スマホのSafari**やPCのブラウザで開きます。
- ヒーローのSplineの車が表示され、**ドラッグ／指で回せます**。
- 下にスクロールすると、TikTokセクションに**実際の動画**が出ます。

これで「白くて見えない」問題は完全に解決です。

---

## STEP 6. 中身（TikTokのID・ブログURL・メール）を更新する

設定値は `src/lib/site.ts` の1ファイルにまとまっています。
GitHub上で直接編集すると、**保存するたびVercelが自動で再公開**します。

1. GitHubのリポジトリで `src` → `lib` → `site.ts` を開く
2. 右上の **鉛筆アイコン（Edit）** を押す
3. 値を書き換える：
   - `tiktokHandle: "paradosxia"` → 自分の @ハンドル（@は不要）
   - `blog: "https://renchicun4.com"` → ブログURL
   - `email: "hello@paradosxia.com"` → 連絡先メール
   - 特定の動画だけ出したいときは
     `tiktokVideos: []` → `tiktokVideos: ["動画ID1", "動画ID2"]`
     （動画IDは共有URL `tiktok.com/@you/video/●●●●` の `●●●●` 部分）
4. **Commit changes** を押す → 数十秒後に自動で反映

---

## STEP 7.（任意）独自ドメインを設定する

1. Vercelのプロジェクト → **Settings** → **Domains**
2. 持っているドメイン（例 `paradosxia.com`）を入力して **Add**
3. 表示されるDNS設定を、ドメイン会社の管理画面に入れる

---

## うまくいかないとき

- **ビルドに失敗した** … トップに `package.json` が無い可能性大。STEP3をやり直すか、STEP4でRoot Directoryを`paradosxia`に。
- **Splineが白い** … 公開URL（`vercel.app`）ではなくローカルファイルやアプリ内プレビューで見ていないか確認。
- **TikTokが出ない** … `site.ts` の `tiktokHandle` が正しい@ハンドルになっているか確認。
